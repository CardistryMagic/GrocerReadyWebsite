# Michael Shi's Profile Website: ICS2O7 2017
Website for ICS2O7 class of 2017 Web developement assignment

Also serves as my personal profile.
